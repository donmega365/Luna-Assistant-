package com.luna.assistant
import android.content.SharedPreferences
import org.json.*
import java.net.*

object AiClient {
    val provs = linkedMapOf(
        "GitHub" to "https://github.com/settings/tokens",
        "Groq" to "https://console.groq.com/keys",
        "Cerebras" to "https://cloud.cerebras.ai",
        "Gemini" to "https://aistudio.google.com/apikey",
        "Claude" to "https://console.anthropic.com/settings/keys",
        "ChatGPT" to "https://platform.openai.com/api-keys")
    private const val SYS = "You are Luna, a smart, friendly voice assistant on the user's phone. Answer in 1-3 short sentences, in the same language the user speaks (Hindi, Hinglish, English, any). No markdown, no emojis."
    private val hist = ArrayList<Pair<String, String>>()   // (user|assistant) to text, last few turns
    private val models = HashMap<String, String>()

    private fun http(method: String, url: String, h: Map<String, String>, body: String?): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method; c.connectTimeout = 15000; c.readTimeout = 40000
        h.forEach { (k, v) -> c.setRequestProperty(k, v) }
        if (body != null) { c.doOutput = true; c.setRequestProperty("Content-Type", "application/json"); c.outputStream.use { it.write(body.toByteArray()) } }
        val code = c.responseCode
        val txt = (if (code < 400) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        if (code >= 400) {
            val msg = try { val j = JSONObject(txt); j.optJSONObject("error")?.optString("message") ?: j.optString("message", txt) } catch (e: Exception) { txt }
            throw Exception("HTTP $code ${msg.take(120)}")
        }
        return txt
    }
    // Picks the newest suitable model from the provider's own /models list, so old model names never break the app
    private fun pick(name: String, base: String, key: String, prefer: List<String>, fb: String): String {
        models[name]?.let { return it }
        try {
            val d = JSONObject(http("GET", "$base/models", mapOf("Authorization" to "Bearer $key"), null)).getJSONArray("data")
            val ids = (0 until d.length()).map { d.getJSONObject(it).getString("id") }
                .filter { id -> listOf("whisper", "guard", "tts", "embed", "orpheus", "audio", "image").none { id.contains(it) } }
            for (p in prefer) ids.firstOrNull { it.contains(p) }?.let { models[name] = it; return it }
        } catch (e: Exception) {}
        return fb
    }
    private fun claudeModel(key: String): String {
        models["Claude"]?.let { return it }
        try {
            val d = JSONObject(http("GET", "https://api.anthropic.com/v1/models", mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), null)).getJSONArray("data")
            for (i in 0 until d.length()) { val id = d.getJSONObject(i).getString("id"); if (id.contains("sonnet")) { models["Claude"] = id; return id } }
        } catch (e: Exception) {}
        return "claude-sonnet-5-5"
    }
    private fun chat(url: String, key: String, model: String, q: String, useHist: Boolean): String {
        val m = JSONArray().put(JSONObject().put("role", "system").put("content", SYS))
        if (useHist) hist.forEach { m.put(JSONObject().put("role", it.first).put("content", it.second)) }
        m.put(JSONObject().put("role", "user").put("content", q))
        val r = JSONObject(http("POST", url, mapOf("Authorization" to "Bearer $key"), JSONObject().put("model", model).put("messages", m).put("max_tokens", 300).toString()))
        return r.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
    }
    private fun raw(provider: String, key: String, q: String, useHist: Boolean): String = when (provider) {
        "Gemini" -> {
            val c = JSONArray()
            if (useHist) hist.forEach { c.put(JSONObject().put("role", if (it.first == "user") "user" else "model").put("parts", JSONArray().put(JSONObject().put("text", it.second)))) }
            c.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", q))))
            val b = JSONObject().put("contents", c).put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYS))))
            JSONObject(http("POST", "https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent?key=$key", mapOf(), b.toString()))
                .getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        }
        "Claude" -> {
            val m = JSONArray()
            if (useHist) hist.forEach { m.put(JSONObject().put("role", it.first).put("content", it.second)) }
            m.put(JSONObject().put("role", "user").put("content", q))
            val b = JSONObject().put("model", claudeModel(key)).put("max_tokens", 400).put("system", SYS).put("messages", m)
            JSONObject(http("POST", "https://api.anthropic.com/v1/messages", mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), b.toString()))
                .getJSONArray("content").getJSONObject(0).getString("text")
        }
        "GitHub" -> chat("https://models.github.ai/inference/chat/completions", key, "openai/gpt-4o-mini", q, useHist)
        "Groq" -> chat("https://api.groq.com/openai/v1/chat/completions", key, pick("Groq", "https://api.groq.com/openai/v1", key, listOf("llama-3.3-70b", "llama-3.1-70b", "llama-3.1-8b", "llama"), "llama-3.3-70b-versatile"), q, useHist)
        "Cerebras" -> chat("https://api.cerebras.ai/v1/chat/completions", key, pick("Cerebras", "https://api.cerebras.ai/v1", key, listOf("llama-3.3-70b", "llama3.1-8b", "llama"), "llama3.1-8b"), q, useHist)
        else -> chat("https://api.openai.com/v1/chat/completions", key, pick("ChatGPT", "https://api.openai.com/v1", key, listOf("gpt-4o-mini", "gpt-4.1-mini", "mini"), "gpt-4o-mini"), q, useHist)
    }
    @Synchronized fun ask(provider: String, key: String, q: String): String {
        val a = raw(provider, key, q, true).trim()
        hist.add("user" to q); hist.add("assistant" to a); while (hist.size > 12) hist.removeAt(0)
        return a
    }
    fun test(provider: String, key: String): String {
        if (key.isEmpty()) return "✗ Pehle key daalo"
        return try { raw(provider, key, "Reply with the single word OK", false); "✓ $provider chal raha hai" } catch (e: Exception) { "✗ ${e.message}" }
    }
    // Selected AI first, then auto-failover to any other AI that has a saved key
    fun askAny(p: SharedPreferences, q: String): String {
        val first = p.getString("prov", "GitHub") ?: "GitHub"
        var err = ""; var any = false
        for (n in listOf(first) + provs.keys.filter { it != first }) {
            val k = p.getString("key_$n", "") ?: ""
            if (k.isEmpty()) continue
            any = true
            try { return ask(n, k, q) } catch (e: Exception) { err = "$n: ${e.message}" }
        }
        return if (!any) "Sir, pehle AI tab mein koi key ya token add kijiye" else "Sir, sab AI fail ho gaye ($err)"
    }
}
