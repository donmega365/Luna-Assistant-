package com.luna.assistant
import android.Manifest
import android.app.Activity
import android.app.ActivityManager
import android.content.*
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import android.view.*
import android.widget.*
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val provs = AiClient.provs.keys.toTypedArray()
    private lateinit var p: SharedPreferences
    private lateinit var holder: FrameLayout
    private var dark = true
    private val fg get() = if (dark) Color.WHITE else Color.parseColor("#2A1B4D")
    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun col() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun tv(t: String, sz: Float = 15f) = TextView(this).apply { text = t; textSize = sz; setTextColor(fg) }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; setTextColor(Color.WHITE); isAllCaps = false
        background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFFFF6EC7.toInt(), 0xFF8E4DFF.toInt())).apply { cornerRadius = dp(22).toFloat() }
        setOnClickListener { f() }
    }
    private fun card(vararg v: View) = col().apply {
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = GradientDrawable().apply { cornerRadius = dp(22).toFloat(); setColor(if (dark) 0x33FFFFFF else 0x66FFFFFF) }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(12)) }
        v.forEach { addView(it) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        p = getSharedPreferences("luna", 0); dark = p.getBoolean("dark", true)
        holder = FrameLayout(this)
        val tabs = LinearLayout(this).apply { setPadding(dp(8), dp(6), dp(8), dp(12)) }
        val pages = listOf<Pair<String, () -> View>>("🏠\nHome" to ::homePage, "⚡\nBoost" to ::boostPage, "🔐\nPerms" to ::permsPage, "🤖\nAI" to ::aiPage, "🎮\nGames" to ::gamesPage)
        for ((n, f) in pages) tabs.addView(btn(n) { show(f) }.apply { textSize = 11f; setPadding(0, 0, 0, 0); layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
        val c = col().apply {
            setPadding(0, dp(36), 0, 0)
            addView(tv("Luna  ✦", 30f).apply { setPadding(dp(18), 0, 0, 0) })
            addView(holder, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(tabs)
        }
        setContentView(FrameLayout(this).apply { addView(AuraView(this@MainActivity, dark)); addView(c) })
        show(::homePage)
    }
    private fun show(f: () -> View) {
        holder.removeAllViews()
        val v = try { f() } catch (e: Throwable) { tv("Page error: $e\n" + e.stackTrace.take(4).joinToString("\n"), 13f) }
        v.setPadding(dp(14), dp(8), dp(14), dp(8))
        if (v.tag == "fixed") holder.addView(v, FrameLayout.LayoutParams(-1, -1)) else holder.addView(ScrollView(this).apply { addView(v) })
    }
    override fun onResume() { super.onResume(); LunaService.onMsg = { me, t -> runOnUiThread { bubble(me, t) } } }
    override fun onPause() { super.onPause(); LunaService.onMsg = null }
    private fun startLuna() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            startForegroundService(Intent(this, LunaService::class.java))
        else requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
    }
    override fun onRequestPermissionsResult(c: Int, ps: Array<out String>, r: IntArray) { if (c == 1) { if (r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) startLuna() else Toast.makeText(this, "Luna ko sunne ke liye Mic permission chahiye", Toast.LENGTH_LONG).show() } }

    private var logView: LinearLayout? = null
    private var chatScroll: ScrollView? = null
    private var torchOn = false
    private fun bubble(me: Boolean, t: String) {
        val l = logView ?: return
        l.addView(TextView(this).apply {
            text = t; textSize = 15f; setTextColor(if (me) Color.WHITE else fg)
            setPadding(dp(14), dp(10), dp(14), dp(10)); maxWidth = (resources.displayMetrics.widthPixels * 0.75f).toInt()
            background = GradientDrawable().apply { cornerRadius = dp(18).toFloat(); setColor(if (me) 0xDD8E4DFF.toInt() else if (dark) 0x44FFFFFF else 0x88FFFFFF.toInt()) }
            layoutParams = LinearLayout.LayoutParams(-2, -2).apply { gravity = if (me) Gravity.END else Gravity.START; setMargins(0, dp(4), 0, dp(4)) }
        })
        chatScroll?.post { chatScroll?.fullScroll(View.FOCUS_DOWN) }
    }
    private fun sendCmd(t: String) { if (t.isBlank()) return; LunaService.add(true, t); Actions.handle(this, t) { LunaService.add(false, it) } }

    private fun homePage(): LinearLayout {
        val status = tv("", 18f); val hint = tv("", 12f)
        fun upd() {
            status.text = if (LunaService.running) "Luna sun rahi hai" else "Luna so rahi hai"
            hint.text = if (LunaService.running) "Bolo \"Hello Luna\" - baaki baat par chup rahegi" else "Mic dabao aur shuru karo"
        }
        val mic = Button(this).apply {
            text = "🎙"; textSize = 36f
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFFFF6EC7.toInt(), 0xFF8E4DFF.toInt())).apply { shape = GradientDrawable.OVAL }
            layoutParams = LinearLayout.LayoutParams(dp(96), dp(96)).apply { setMargins(0, 0, dp(16), 0) }
            setOnClickListener {
                if (LunaService.running) stopService(Intent(this@MainActivity, LunaService::class.java)) else startLuna()
                postDelayed({ upd() }, 800)
            }
        }
        val callBtn = btn("") {}.apply {
            text = if (LunaService.callMode) "📞 Call khatam" else "📞 Call Luna"
            setOnClickListener {
                if (!LunaService.running) startLuna()
                LunaService.callMode = !LunaService.callMode
                text = if (LunaService.callMode) "📞 Call khatam" else "📞 Call Luna"
                LunaService.instance?.say(if (LunaService.callMode) "Ji Sir, boliye" else "Theek hai Sir, call khatam")
            }
        }
        val q = EditText(this).apply { hint = "Luna se type karke poocho"; setTextColor(fg); setHintTextColor(Color.GRAY) }
        val log = col().also { logView = it }
        val sc = ScrollView(this).also { chatScroll = it }.apply { addView(log) }
        synchronized(LunaService.chat) { LunaService.chat.toList() }.forEach { (me, t) -> bubble(me, t) }
        upd()
        return col().apply {
            tag = "fixed"
            p.getString("crash", null)?.let { cr -> addView(card(tv("Pichli baar crash hua - ye text mujhe bhejo:", 13f), tv(cr, 10f).apply { setTextIsSelectable(true) }, btn("Clear") { p.edit().remove("crash").apply(); show(::homePage) })) }
            addView(card(LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL; addView(mic); addView(col().apply { addView(status); addView(hint) }) }))
            addView(LinearLayout(this@MainActivity).apply {
                addView(callBtn, LinearLayout.LayoutParams(0, -2, 1.4f))
                addView(btn("🔦") { torchOn = !torchOn; sendCmd(if (torchOn) "torch on" else "torch off") }, LinearLayout.LayoutParams(0, -2, 0.6f))
                addView(btn("▶") { sendCmd("youtube") }, LinearLayout.LayoutParams(0, -2, 0.6f))
            })
            addView(sc, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(LinearLayout(this@MainActivity).apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(q, LinearLayout.LayoutParams(0, -2, 1f))
                addView(btn("Send") { sendCmd(q.text.toString()); q.setText("") })
            })
        }
    }

    private fun boostPage(): LinearLayout {
        val info = tv("")
        fun refresh() {
            val mi = ActivityManager.MemoryInfo(); getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
            val bt = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0)?.div(10f) ?: 0f
            val rssi = try { (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).connectionInfo.rssi } catch (e: Exception) { -127 }
            val w = if (rssi > -60) "strong" else if (rssi > -75) "theek" else "weak - router ke paas jao"
            val base = "RAM free: ${mi.availMem / 1048576} / ${mi.totalMem / 1048576} MB\nBattery temp: $bt °C\nWiFi signal: $rssi dBm ($w)"
            info.text = base
            thread {
                val t0 = System.nanoTime()
                val ms = try { Socket().use { it.connect(InetSocketAddress("8.8.8.8", 53), 2000) }; ((System.nanoTime() - t0) / 1000000).toString() } catch (e: Exception) { "no net" }
                runOnUiThread { info.text = "$base\nPing: $ms ms" }
            }
        }
        refresh()
        return col().apply {
            addView(card(tv("Lag check", 18f), info, btn("Refresh") { refresh() }))
            addView(card(tv("Game Boost: background apps band karta hai taaki game smooth chale. Android kuch apps wapas khol sakta hai."),
                btn("Game Boost ON") {
                    val am = getSystemService(ActivityManager::class.java); var n = 0
                    for (a in packageManager.getInstalledApplications(0))
                        if (a.flags and ApplicationInfo.FLAG_SYSTEM == 0 && a.packageName != packageName) { am.killBackgroundProcesses(a.packageName); n++ }
                    Toast.makeText(this@MainActivity, "$n apps ko band karne bheja", Toast.LENGTH_SHORT).show(); refresh()
                }))
        }
    }

    private fun permsPage(): LinearLayout {
        val all = listOf("Mic (awaaz sunne ke liye)" to Manifest.permission.RECORD_AUDIO, "Call" to Manifest.permission.CALL_PHONE,
            "SMS" to Manifest.permission.SEND_SMS, "Contacts" to Manifest.permission.READ_CONTACTS, "Notifications" to Manifest.permission.POST_NOTIFICATIONS)
        val boxes = all.map { (n, perm) -> CheckBox(this).apply { text = n; setTextColor(fg); isChecked = checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED } }
        return col().apply {
            addView(card(tv("Jo permission dena hai wahi select karo", 16f), *boxes.toTypedArray(),
                btn("Allow selected") { val sel = all.filterIndexed { i, _ -> boxes[i].isChecked }.map { it.second }.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }; if (sel.isEmpty()) Toast.makeText(this@MainActivity, "Koi nayi permission select nahi ki", Toast.LENGTH_SHORT).show() else requestPermissions(sel.toTypedArray(), 2) }))
            addView(card(tv("Background mein apps kholne ke liye"), btn("Display over apps") {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }))
        }
    }

    private fun openGame(f: () -> View) {
        val v = try { f() } catch (e: Throwable) { tv("Game error: $e") }
        holder.removeAllViews()
        holder.addView(ScrollView(this).apply { addView(col().apply { setPadding(dp(14), dp(8), dp(14), dp(8)); addView(card(v)); addView(btn("Back") { show(::gamesPage) }) }) })
    }
    private fun gamesPage(): LinearLayout = col().apply {
        addView(card(tv("Offline games (bina internet)", 18f),
            btn("Tic-Tac-Toe vs Luna AI") { openGame { Games.ttt(this@MainActivity, fg) } },
            btn("2048") { openGame { Games.g2048(this@MainActivity, fg) } },
            btn("Snake") { openGame { Games.snake(this@MainActivity, fg) } },
            btn("Memory match") { openGame { Games.memory(this@MainActivity, fg) } }))
    }

    private fun aiPage(): LinearLayout {
        val names = provs.map { it + if (!p.getString("key_$it", "").isNullOrEmpty()) " ✓" else "" }
        val sp = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, names); setSelection(provs.indexOf(p.getString("prov", "GitHub")).coerceAtLeast(0)) }
        val key = EditText(this).apply { hint = "API key / GitHub token"; setText(p.getString("key_" + provs[sp.selectedItemPosition], "")); setTextColor(fg); setHintTextColor(Color.GRAY) }
        val st = tv("", 14f)
        fun cur() = provs[sp.selectedItemPosition]
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(a: AdapterView<*>?, v: View?, i: Int, l: Long) { key.setText(p.getString("key_" + provs[i], "")) }
            override fun onNothingSelected(a: AdapterView<*>?) {}
        }
        val langs = listOf("Auto" to "", "Hindi" to "hi-IN", "English (India)" to "en-IN")
        val lsp = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, langs.map { it.first })
            setSelection(langs.indexOfFirst { it.second == p.getString("lang", "") }.coerceAtLeast(0))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(a: AdapterView<*>?, v: View?, i: Int, l: Long) { p.edit().putString("lang", langs[i].second).apply() }
                override fun onNothingSelected(a: AdapterView<*>?) {}
            }
        }
        return col().apply {
            addView(card(tv("AI chuno (fail ho to agla auto lagega)", 16f), sp, key,
                btn("🔑 Get key / token") { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(AiClient.provs[cur()] ?: ""))) },
                btn("✅ Test") { st.text = "Test ho raha hai..."; val pr = cur(); val k = key.text.toString().trim(); thread { val r = AiClient.test(pr, k); runOnUiThread { st.text = r } } },
                btn("💾 Save") { p.edit().putString("prov", cur()).putString("key_" + cur(), key.text.toString().trim()).apply(); st.text = "Save ho gaya" }, st))
            addView(card(tv("Bolne ki bhasha (Luna ko stop/start karo)"), lsp))
            addView(card(btn(if (dark) "☀ Light theme" else "🌙 Dark theme") { p.edit().putBoolean("dark", !dark).apply(); recreate() }))
        }
    }
}
