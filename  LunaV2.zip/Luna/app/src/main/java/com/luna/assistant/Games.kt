package com.luna.assistant
import android.content.Context
import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.view.*
import android.widget.*
import kotlin.math.abs
import kotlin.random.Random

// 4 offline games (no internet): Tic-Tac-Toe vs Luna AI, 2048, Snake, Memory
object Games {
    private fun dp(c: Context, x: Int) = (x * c.resources.displayMetrics.density).toInt()
    private fun row(c: Context, vararg v: View) = LinearLayout(c).apply {
        v.forEach { addView(it, LinearLayout.LayoutParams(0, dp(c, 78), 1f).apply { setMargins(4, 4, 4, 4) }) }
    }
    private fun label(c: Context, fg: Int, t: String) = TextView(c).apply { text = t; setTextColor(fg); textSize = 16f }

    fun ttt(c: Context, fg: Int): View {
        val bd = CharArray(9) { ' ' }
        val cells = Array(9) { Button(c).apply { textSize = 28f } }
        val st = label(c, fg, "Aap X ho, Luna O hai")
        val lines = arrayOf(intArrayOf(0, 1, 2), intArrayOf(3, 4, 5), intArrayOf(6, 7, 8), intArrayOf(0, 3, 6), intArrayOf(1, 4, 7), intArrayOf(2, 5, 8), intArrayOf(0, 4, 8), intArrayOf(2, 4, 6))
        fun win(): Char {
            for (l in lines) if (bd[l[0]] != ' ' && bd[l[0]] == bd[l[1]] && bd[l[1]] == bd[l[2]]) return bd[l[0]]
            return if (bd.none { it == ' ' }) 'D' else ' '
        }
        fun mm(ai: Boolean): Int {
            when (win()) { 'O' -> return 1; 'X' -> return -1; 'D' -> return 0 }
            var best = if (ai) -2 else 2
            for (i in 0..8) if (bd[i] == ' ') {
                bd[i] = if (ai) 'O' else 'X'; val s = mm(!ai); bd[i] = ' '
                best = if (ai) maxOf(best, s) else minOf(best, s)
            }
            return best
        }
        fun refresh() {
            for (i in 0..8) cells[i].text = if (bd[i] == ' ') "" else bd[i].toString()
            when (win()) { 'X' -> st.text = "Aap jeet gaye!"; 'O' -> st.text = "Luna jeet gayi!"; 'D' -> st.text = "Draw" }
        }
        for (i in 0..8) cells[i].setOnClickListener {
            if (bd[i] == ' ' && win() == ' ') {
                bd[i] = 'X'
                if (win() == ' ') {
                    var bi = -1; var bs = -2
                    for (j in 0..8) if (bd[j] == ' ') { bd[j] = 'O'; val s = mm(false); bd[j] = ' '; if (s > bs) { bs = s; bi = j } }
                    if (bi >= 0) bd[bi] = 'O'
                }
                refresh()
            }
        }
        return LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            addView(st)
            for (r in 0..2) addView(row(c, cells[r * 3], cells[r * 3 + 1], cells[r * 3 + 2]))
            addView(Button(c).apply { text = "Restart"; setOnClickListener { for (i in 0..8) bd[i] = ' '; st.text = "Aap X ho, Luna O hai"; refresh() } })
        }
    }

    fun memory(c: Context, fg: Int): View {
        val em = listOf("🌸", "🦊", "🐱", "🍙", "⭐", "🎧", "🌙", "🔥")
        val cards = (em + em).shuffled()
        val b = Array(16) { Button(c).apply { text = "?"; textSize = 24f } }
        val done = BooleanArray(16); var first = -1; var lock = false
        for (i in 0..15) b[i].setOnClickListener {
            if (lock || done[i] || i == first) return@setOnClickListener
            b[i].text = cards[i]
            if (first < 0) first = i
            else if (cards[first] == cards[i]) { done[first] = true; done[i] = true; first = -1 }
            else {
                val f = first; first = -1; lock = true
                Handler(Looper.getMainLooper()).postDelayed({ b[f].text = "?"; b[i].text = "?"; lock = false }, 700)
            }
        }
        return LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            addView(label(c, fg, "Jodiyan milao"))
            for (r in 0..3) addView(row(c, b[r * 4], b[r * 4 + 1], b[r * 4 + 2], b[r * 4 + 3]))
        }
    }

    fun g2048(c: Context, fg: Int): View {
        val g = Array(4) { IntArray(4) }
        val cells = Array(16) { TextView(c).apply { gravity = Gravity.CENTER; textSize = 22f; setTextColor(Color.WHITE) } }
        fun add() {
            val e = (0..15).filter { g[it / 4][it % 4] == 0 }
            if (e.isNotEmpty()) { val k = e.random(); g[k / 4][k % 4] = if (Random.nextInt(10) == 0) 4 else 2 }
        }
        fun draw() {
            for (i in 0..15) {
                val v = g[i / 4][i % 4]
                cells[i].text = if (v == 0) "" else "$v"
                cells[i].setBackgroundColor(if (v == 0) 0x33FFFFFF else Color.HSVToColor(floatArrayOf((Integer.numberOfTrailingZeros(v) * 40f) % 360f, 0.6f, 0.9f)))
            }
        }
        fun slide(line: IntArray): IntArray {
            val nz = line.filter { it != 0 }.toMutableList()
            var i = 0
            while (i < nz.size - 1) { if (nz[i] == nz[i + 1]) { nz[i] *= 2; nz.removeAt(i + 1) }; i++ }
            while (nz.size < 4) nz.add(0)
            return nz.toIntArray()
        }
        fun move(dir: Int) { // 0 left, 1 right, 2 up, 3 down
            var moved = false
            for (k in 0..3) {
                val line = IntArray(4) { when (dir) { 0 -> g[k][it]; 1 -> g[k][3 - it]; 2 -> g[it][k]; else -> g[3 - it][k] } }
                val r = slide(line)
                if (!r.contentEquals(line)) moved = true
                for (j in 0..3) {
                    when (dir) {
                        0 -> g[k][j] = r[j]
                        1 -> g[k][3 - j] = r[j]
                        2 -> g[j][k] = r[j]
                        else -> g[3 - j][k] = r[j]
                    }
                }
            }
            if (moved) add()
            draw()
        }
        add(); add(); draw()
        val gd = GestureDetector(c, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onFling(a: MotionEvent?, b: MotionEvent, vx: Float, vy: Float): Boolean {
                if (abs(vx) > abs(vy)) move(if (vx > 0) 1 else 0) else move(if (vy > 0) 3 else 2)
                return true
            }
        })
        val grid = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            for (r in 0..3) addView(row(c, cells[r * 4], cells[r * 4 + 1], cells[r * 4 + 2], cells[r * 4 + 3]))
            setOnTouchListener { v, e -> v.parent.requestDisallowInterceptTouchEvent(true); gd.onTouchEvent(e); true }
        }
        return LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; addView(label(c, fg, "Swipe karo")); addView(grid) }
    }

    fun snake(c: Context, fg: Int): View =
        LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; addView(label(c, fg, "Swipe se ghumao")); addView(SnakeView(c)) }
}

class SnakeView(c: Context) : View(c) {
    private val n = 16
    private val sn = ArrayList<Int>()
    private var dx = 1; private var dy = 0; private var food = 0; private var over = false; private var score = 0
    private val h = Handler(Looper.getMainLooper())
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 48f }
    private var sx = 0f; private var sy = 0f
    init { reset() }
    private fun reset() { sn.clear(); sn.addAll(listOf(8 * n + 4, 8 * n + 3, 8 * n + 2)); dx = 1; dy = 0; over = false; score = 0; food = newFood() }
    private fun newFood(): Int { var r: Int; do { r = Random.nextInt(n * n) } while (sn.contains(r)); return r }
    private val tick = object : Runnable {
        override fun run() {
            val hx = sn[0] % n + dx; val hy = sn[0] / n + dy
            if (hx < 0 || hy < 0 || hx >= n || hy >= n || sn.contains(hy * n + hx)) { over = true; invalidate(); return }
            sn.add(0, hy * n + hx)
            if (sn[0] == food) { score++; food = newFood() } else sn.removeAt(sn.size - 1)
            invalidate(); h.postDelayed(this, 170)
        }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); h.post(tick) }
    override fun onDetachedFromWindow() { h.removeCallbacksAndMessages(null); super.onDetachedFromWindow() }
    override fun onMeasure(w: Int, hh: Int) { val s = MeasureSpec.getSize(w); setMeasuredDimension(s, s) }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        when (e.action) {
            MotionEvent.ACTION_DOWN -> { sx = e.x; sy = e.y }
            MotionEvent.ACTION_UP -> {
                val ax = e.x - sx; val ay = e.y - sy
                if (over && abs(ax) < 20 && abs(ay) < 20) { reset(); h.post(tick) }
                else if (abs(ax) > abs(ay)) { if (ax > 0 && dx == 0) { dx = 1; dy = 0 } else if (ax < 0 && dx == 0) { dx = -1; dy = 0 } }
                else { if (ay > 0 && dy == 0) { dx = 0; dy = 1 } else if (ay < 0 && dy == 0) { dx = 0; dy = -1 } }
            }
        }
        return true
    }
    override fun onDraw(cv: Canvas) {
        val s = width / n.toFloat()
        p.color = 0x33FFFFFF; cv.drawRect(0f, 0f, width.toFloat(), width.toFloat(), p)
        p.color = Color.rgb(255, 110, 199); cv.drawCircle((food % n + 0.5f) * s, (food / n + 0.5f) * s, s / 2.4f, p)
        p.color = Color.rgb(120, 255, 170)
        for (i in sn) cv.drawRoundRect((i % n) * s + 2, (i / n) * s + 2, (i % n + 1) * s - 2, (i / n + 1) * s - 2, 8f, 8f, p)
        p.color = Color.WHITE; cv.drawText(if (over) "Game over $score - tap" else "Score $score", 16f, 56f, p)
    }
}
