package com.luna.assistant
import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import java.util.Locale

class LunaService : Service() {
    companion object {
        var running = false; var callMode = false; var instance: LunaService? = null
        val chat = ArrayList<Pair<Boolean, String>>()
        var onMsg: ((Boolean, String) -> Unit)? = null
        fun add(me: Boolean, t: String) {
            synchronized(chat) { chat.add(me to t); if (chat.size > 30) chat.removeAt(0) }
            onMsg?.invoke(me, t)
        }
        private val WAKE = Regex("(?:(?:hello|hey|hi|okay|ok)\\s+)?(?:\\bluna+\\b|\\bloo?na\\b|लूना|लुना)")
        private val BYE = Regex("\\b(bye|hang up|call band|call end|alvida)\\b")
    }
    private lateinit var tts: TextToSpeech
    private var sr: SpeechRecognizer? = null
    private val h = Handler(Looper.getMainLooper())
    private var awakeUntil = 0L; private var pending = 0; private var alive = true

    override fun onCreate() {
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("luna", "Luna", NotificationManager.IMPORTANCE_LOW))
            val n = Notification.Builder(this, "luna").setContentTitle("Luna sun rahi hai - \"Hello Luna\" bolo").setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(1, n)
            if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                Toast.makeText(this, "Is phone mein speech recognition nahi hai (Google app chahiye)", Toast.LENGTH_LONG).show(); stopSelf(); return
            }
            running = true; instance = this
            val lg = getSharedPreferences("luna", 0).getString("lang", "") ?: ""
            tts = TextToSpeech(this) {
                tts.language = if (lg.isEmpty()) Locale.getDefault() else Locale.forLanguageTag(lg)
                tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { h.post { pending = maxOf(0, pending - 1) } }
                    override fun onError(id: String?) { h.post { pending = maxOf(0, pending - 1) } }
                })
                if (callMode) say("Ji Sir, boliye")
                listen()
            }
        } catch (e: Throwable) { getSharedPreferences("luna", 0).edit().putString("crash", "Service: $e").apply(); stopSelf() }
    }
    // Luna bolti hai; bolte waqt mic band rehta hai taaki wo apni hi awaaz na sune
    fun say(s: String) {
        add(false, s)
        h.post {
            if (!::tts.isInitialized) return@post
            pending++; sr?.cancel()
            tts.speak(s.take(500), TextToSpeech.QUEUE_ADD, null, "u" + System.nanoTime())
        }
    }
    private fun process(t: String) {
        val l = t.lowercase().trim()
        val m = WAKE.find(l)
        val now = System.currentTimeMillis()
        // Insaan se normal baat ho rahi ho to Luna chup rehti hai
        if (!callMode && m == null && now >= awakeUntil) return
        val cmd = (if (m != null) l.removeRange(m.range) else l).trim()
        if (callMode && BYE.containsMatchIn(cmd)) { callMode = false; say("Theek hai Sir, call khatam"); return }
        if (cmd.isEmpty()) { awakeUntil = now + 10000; say("Yes Sir"); return }
        awakeUntil = 0
        add(true, cmd)
        Actions.handle(this, cmd) { say(it) }
    }
    private fun listen() { try { listenNow() } catch (e: Throwable) { h.postDelayed({ listen() }, 3000) } }
    private fun listenNow() {
        if (!alive) return
        if (pending > 0) { h.postDelayed({ listen() }, 500); return }
        sr?.destroy()
        val lg = getSharedPreferences("luna", 0).getString("lang", "") ?: ""
        sr = SpeechRecognizer.createSpeechRecognizer(this).also { r ->
            r.setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle?) { b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { process(it) }; h.postDelayed({ listen() }, 300) }
                override fun onError(e: Int) { h.postDelayed({ listen() }, 800) }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(b: Bundle?) {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            if (lg.isNotEmpty()) i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lg)
            r.startListening(i)
        }
    }
    override fun onStartCommand(i: Intent?, f: Int, s: Int) = START_STICKY
    override fun onBind(i: Intent?): IBinder? = null
    override fun onDestroy() {
        alive = false; running = false; callMode = false; instance = null
        h.removeCallbacksAndMessages(null); sr?.destroy(); if (::tts.isInitialized) tts.shutdown()
    }
}
