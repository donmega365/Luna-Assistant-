package com.luna.assistant
import android.Manifest
import android.app.Activity
import android.app.ActivityManager
import android.content.*
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.RippleDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import android.view.*
import android.widget.*
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val provs = AiClient.provs.keys.toTypedArray()
    private lateinit var p: SharedPreferences
    private lateinit var holder: FrameLayout
    private val tabViews = ArrayList<TextView>()
    private var red = true
    private val fg: Int = Color.WHITE
    private val acc1: Int get() = if (red) 0xFFFF3B55.toInt() else 0xFFFF6EC7.toInt()
    private val acc2: Int get() = if (red) 0xFFA3102A.toInt() else 0xFF8E4DFF.toInt()
    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun col() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun tv(t: String, sz: Float = 15f) = TextView(this).apply { text = t; textSize = sz; setTextColor(fg) }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; setTextColor(Color.WHITE); isAllCaps = false
        background = RippleDrawable(ColorStateList.valueOf(0x55FFFFFF), GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(acc1, acc2)).apply { cornerRadius = dp(22).toFloat() }, null)
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); elevation = dp(3).toFloat()
        setOnClickListener { f() }
    }
    private fun card(vararg v: View) = col().apply {
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = GradientDrawable().apply {
            cornerRadius = dp(26).toFloat(); setColor(if (red) 0xB3120508.toInt() else 0x66FFFFFF); setStroke(dp(1), if (red) 0x88FF3B55.toInt() else 0x44FFFFFF)
        }
        elevation = dp(6).toFloat()
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(12)) }
        v.forEach { addView(it) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        p = getSharedPreferences("luna", 0); red = p.getBoolean("red", true)
        holder = FrameLayout(this)
        val tabs = LinearLayout(this).apply {
            setPadding(dp(6), dp(4), dp(6), dp(4)); elevation = dp(8).toFloat()
            background = GradientDrawable().apply { cornerRadius = dp(30).toFloat(); setColor(0xCC120508.toInt()); setStroke(dp(1), 0x55FF3B55) }
        }
        val pages = listOf<Pair<String, () -> View>>("🏠\nHome" to ::homePage, "💬\nChat" to ::chatPage, "⚡\nBoost" to ::boostPage, "🎮\nGames" to ::gamesPage, "⚙\nSettings" to ::settingsPage)
        pages.forEachIndexed { i, (n, f) ->
            val t = TextView(this).apply { text = n; textSize = 11f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(8)); setOnClickListener { show(f, i) } }
            tabViews.add(t); tabs.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        }
        val c = col().apply {
            setPadding(0, dp(36), 0, 0)
            addView(col().apply { setPadding(dp(18), 0, 0, dp(4)); addView(tv("Luna", 30f).apply { typeface = Typeface.create("sans-serif-medium", Typeface.BOLD); letterSpacing = 0.08f }); addView(tv("Your Smart Phone Assistant", 12f)) })
            addView(holder, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(tabs, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), 0, dp(12), dp(12)) })
        }
        setContentView(FrameLayout(this).apply { addView(AuraView(this@MainActivity, red)); addView(c) })
        show(::homePage, 0)
    }
    private fun show(f: () -> View, idx: Int = -1) {
        if (idx >= 0) tabViews.forEachIndexed { j, t ->
            t.background = if (j == idx) GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(acc1, acc2)).apply { cornerRadius = dp(22).toFloat() } else null
            t.alpha = if (j == idx) 1f else 0.65f
        }
        holder.removeAllViews(); charAnim?.cancel(); charView = null; speechTv = null
        val v = try { f() } catch (e: Throwable) { tv("Page error: $e\n" + e.stackTrace.take(4).joinToString("\n"), 13f) }
        v.setPadding(dp(14), dp(8), dp(14), dp(8))
        if (v.tag == "fixed") holder.addView(v, FrameLayout.LayoutParams(-1, -1)) else holder.addView(ScrollView(this).apply { addView(v) })
    }
    override fun onResume() {
        super.onResume()
        LunaService.onMsg = { me, t -> runOnUiThread { bubble(me, t); if (!me) speechTv?.text = t.take(140) } }
        LunaService.onState = { s -> runOnUiThread { animChar(s) } }
    }
    override fun onPause() { super.onPause(); LunaService.onMsg = null; LunaService.onState = null; charAnim?.cancel() }
    private fun startLuna() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            startForegroundService(Intent(this, LunaService::class.java))
        else requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
    }
    override fun onRequestPermissionsResult(c: Int, ps: Array<out String>, r: IntArray) {
        if (c == 1) { if (r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) startLuna() else Toast.makeText(this, "Luna ko sunne ke liye Mic permission chahiye", Toast.LENGTH_LONG).show() }
    }
    private fun toggleCall() {
        if (!LunaService.running) startLuna()
        LunaService.callMode = !LunaService.callMode
        LunaService.instance?.say(if (LunaService.callMode) "Ji Sir, boliye" else "Theek hai Sir, call khatam")
        Toast.makeText(this, if (LunaService.callMode) "Call mode ON - har baat ka jawab milega" else "Call mode OFF", Toast.LENGTH_SHORT).show()
    }
    private fun pickChar() { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 7) }
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        val uri = d?.data
        if (rc == 7 && res == RESULT_OK && uri != null) try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1; while (o.outWidth / s > 1100 || o.outHeight / s > 1100) s *= 2
            val bm = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s }) }
            File(filesDir, "char.png").outputStream().use { bm?.compress(Bitmap.CompressFormat.PNG, 100, it) }
            show(::homePage)
        } catch (e: Throwable) { Toast.makeText(this, "Photo nahi lag payi: $e", Toast.LENGTH_LONG).show() }
    }

    private var charView: ImageView? = null
    private var speechTv: TextView? = null
    private var charAnim: android.animation.AnimatorSet? = null
    private fun animChar(s: String) {
        charAnim?.cancel()
        val v = charView ?: return
        v.translationY = 0f; v.rotation = 0f; v.scaleX = 1f; v.scaleY = 1f
        fun osc(prop: String, a: Float, b: Float, ms: Long) = android.animation.ObjectAnimator.ofFloat(v, prop, a, b).apply {
            duration = ms; repeatCount = android.animation.ValueAnimator.INFINITE; repeatMode = android.animation.ValueAnimator.REVERSE
        }
        charAnim = android.animation.AnimatorSet().apply {
            when (s) {
                "speaking" -> playTogether(osc("translationY", 0f, -dp(7).toFloat(), 260), osc("scaleX", 1f, 1.025f, 260), osc("scaleY", 1f, 1.025f, 260))
                "thinking" -> playTogether(osc("rotation", -1.5f, 1.5f, 500))
                else -> playTogether(osc("scaleX", 1f, 1.015f, 2200), osc("scaleY", 1f, 1.015f, 2200))
            }
            start()
        }
    }
    private var logView: LinearLayout? = null
    private var chatScroll: ScrollView? = null
    private var torchOn = false
    private fun bubble(me: Boolean, t: String) {
        val l = logView ?: return
        l.addView(TextView(this).apply {
            text = t; textSize = 15f; setTextColor(Color.WHITE)
            setPadding(dp(14), dp(10), dp(14), dp(10)); maxWidth = (resources.displayMetrics.widthPixels * 0.75f).toInt()
            background = GradientDrawable().apply { cornerRadius = dp(18).toFloat(); setColor(if (me) 0xDDB1122B.toInt() else 0x44FFFFFF) }
            layoutParams = LinearLayout.LayoutParams(-2, -2).apply { gravity = if (me) Gravity.END else Gravity.START; setMargins(0, dp(4), 0, dp(4)) }
        })
        chatScroll?.post { chatScroll?.fullScroll(View.FOCUS_DOWN) }
    }
    private fun sendCmd(t: String) {
        if (t.isBlank()) return
        LunaService.add(true, t); LunaService.setState("thinking")
        Actions.handle(this, t) { r ->
            val shown = r.substringBefore('\u0001')
            LunaService.add(false, shown); LunaService.setState("speaking")
            window.decorView.postDelayed({ LunaService.setState("idle") }, 1200L + shown.length * 40L)
        }
    }

    private fun homePage(): LinearLayout {
        val box = FrameLayout(this).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(250)).apply { setMargins(0, 0, 0, dp(10)) } }
        val charFile = File(filesDir, "char.png")
        if (charFile.exists()) {
            box.addView(ImageView(this).also { charView = it }.apply {
                setImageBitmap(BitmapFactory.decodeFile(charFile.path)); scaleType = ImageView.ScaleType.CENTER_CROP
                background = GradientDrawable().apply { cornerRadius = dp(22).toFloat() }; clipToOutline = true
            }, FrameLayout.LayoutParams(-1, -1))
            box.addView(View(this).apply { background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x00000000, 0xAA000000.toInt())).apply { cornerRadius = dp(22).toFloat() } }, FrameLayout.LayoutParams(-1, -1))
            box.addView(tv("Hello! 👋\nHow can I help you today?", 14f).also { speechTv = it }.apply {
                maxWidth = dp(230); setPadding(dp(12), dp(8), dp(12), dp(8))
                background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(0xCC000000.toInt()); setStroke(dp(1), acc1) }
            }, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, dp(10), dp(10)) })
        } else {
            box.addView(card(tv("Apni pasandida anime character ki photo lagao", 16f), btn("🖼 Photo chuno") { pickChar() }), FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
        }
        val wave = WaveView(this, acc1)
        val status = tv("", 14f).apply { gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(10)) }
        fun upd() {
            wave.active = LunaService.running
            status.text = if (LunaService.running) "Luna sun rahi hai - bolo \"Hello Luna\"" else "Luna so rahi hai - mic dabao"
        }
        val mic = Button(this).apply {
            text = "🎙"; textSize = 30f
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(acc1, acc2)).apply { shape = GradientDrawable.OVAL; setStroke(dp(3), 0x66FFFFFF) }
            setOnClickListener {
                if (LunaService.running) stopService(Intent(this@MainActivity, LunaService::class.java)) else startLuna()
                postDelayed({ upd() }, 800)
            }
        }
        val micRow = FrameLayout(this).apply {
            addView(wave, FrameLayout.LayoutParams(-1, dp(90)))
            addView(mic, FrameLayout.LayoutParams(dp(80), dp(80), Gravity.CENTER))
        }
        val mi = ActivityManager.MemoryInfo(); getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
        val fp = mi.availMem * 100 / mi.totalMem
        val ph = if (fp > 30) "Excellent" else if (fp > 15) "Good" else "Low RAM"
        val bat = getSystemService(BatteryManager::class.java).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val chips = LinearLayout(this).apply {
            addView(card(tv("Phone Status", 11f), tv(ph, 16f)), LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(0, 0, dp(6), dp(10)) })
            addView(card(tv("Battery", 11f), tv("$bat%", 16f)), LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(6), 0, 0, dp(10)) })
        }
        val tiles = LinearLayout(this).apply {
            for ((n, f) in listOf<Pair<String, () -> Unit>>("📱\nPhone\nManager" to { show(::boostPage, 2) }, "📞\nAuto\nCall" to { toggleCall() }, "💬\nChat" to { show(::chatPage, 1) }))
                addView(btn(n) { f() }, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(4, 0, 4, 0) })
        }
        upd(); animChar(LunaService.state)
        return col().apply {
            p.getString("crash", null)?.let { cr -> addView(card(tv("Pichli baar crash hua - ye text mujhe bhejo:", 13f), tv(cr, 10f).apply { setTextIsSelectable(true) }, btn("Clear") { p.edit().remove("crash").apply(); show(::homePage) })) }
            addView(box); addView(micRow); addView(status); addView(chips); addView(tiles)
        }
    }

    private fun chatPage(): LinearLayout {
        val callBtn = btn("") {}.apply {
            text = if (LunaService.callMode) "📞 Call khatam" else "📞 Call Luna"
            setOnClickListener { toggleCall(); text = if (LunaService.callMode) "📞 Call khatam" else "📞 Call Luna" }
        }
        val q = EditText(this).apply { hint = "Luna se type karke poocho"; setTextColor(fg); setHintTextColor(Color.GRAY) }
        val log = col().also { logView = it }
        val sc = ScrollView(this).also { chatScroll = it }.apply { addView(log) }
        synchronized(LunaService.chat) { LunaService.chat.toList() }.forEach { (me, t) -> bubble(me, t) }
        return col().apply {
            tag = "fixed"
            addView(LinearLayout(this@MainActivity).apply {
                addView(callBtn, LinearLayout.LayoutParams(0, -2, 1.4f))
                addView(btn("🔦") { torchOn = !torchOn; sendCmd(if (torchOn) "torch on" else "torch off") }, LinearLayout.LayoutParams(0, -2, 0.6f))
                addView(btn("▶") { sendCmd("youtube") }, LinearLayout.LayoutParams(0, -2, 0.6f))
            })
            addView(sc, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(LinearLayout(this@MainActivity).apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(q, LinearLayout.LayoutParams(0, -2, 1f))
                addView(btn("Send") { sendCmd(q.text.toString()); q.setText("") })
            })
        }
    }

    private fun settingsPage(): LinearLayout = col().apply {
        addView(card(tv("Look", 16f), btn("🖼 Character photo chuno") { pickChar() },
            btn("🔊 Voice settings (Hindi/Urdu voice download)") { try { startActivity(Intent("com.android.settings.TTS_SETTINGS")) } catch (e: Exception) { Toast.makeText(this@MainActivity, "Settings > Language > Text-to-speech kholo", Toast.LENGTH_LONG).show() } },
            btn("🎨 Theme badlo (Red / Purple)") { p.edit().putBoolean("red", !red).apply(); recreate() }))
        addView(aiPage()); addView(permsPage())
    }

    private fun boostPage(): LinearLayout {
        val info = tv("")
        fun refresh() {
            val mi = ActivityManager.MemoryInfo(); getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
            val bt = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0)?.div(10f) ?: 0f
            val rssi = try { (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).connectionInfo.rssi } catch (e: Exception) { -127 }
            val w = if (rssi > -60) "strong" else if (rssi > -75) "theek" else "weak - router ke paas jao"
            val base = "RAM free: ${mi.availMem / 1048576} / ${mi.totalMem / 1048576} MB\nBattery temp: $bt °C\nWiFi signal: $rssi dBm ($w)"
            info.text = base
            thread {
                val t0 = System.nanoTime()
                val ms = try { Socket().use { it.connect(InetSocketAddress("8.8.8.8", 53), 2000) }; ((System.nanoTime() - t0) / 1000000).toString() } catch (e: Exception) { "no net" }
                runOnUiThread { info.text = "$base\nPing: $ms ms" }
            }
        }
        refresh()
        return col().apply {
            addView(card(tv("Lag check", 18f), info, btn("Refresh") { refresh() }))
            addView(card(tv("Game Boost: background apps band karta hai taaki game smooth chale. Android kuch apps wapas khol sakta hai."),
                btn("Game Boost ON") {
                    val am = getSystemService(ActivityManager::class.java); var n = 0
                    for (a in packageManager.getInstalledApplications(0))
                        if (a.flags and ApplicationInfo.FLAG_SYSTEM == 0 && a.packageName != packageName) { am.killBackgroundProcesses(a.packageName); n++ }
                    Toast.makeText(this@MainActivity, "$n apps ko band karne bheja", Toast.LENGTH_SHORT).show(); refresh()
                }))
        }
    }

    private fun permsPage(): LinearLayout {
        val all = listOf("Mic (awaaz sunne ke liye)" to Manifest.permission.RECORD_AUDIO, "Call" to Manifest.permission.CALL_PHONE,
            "SMS" to Manifest.permission.SEND_SMS, "Contacts" to Manifest.permission.READ_CONTACTS, "Notifications" to Manifest.permission.POST_NOTIFICATIONS)
        val boxes = all.map { (n, perm) -> CheckBox(this).apply { text = n; setTextColor(fg); isChecked = checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED } }
        return col().apply {
            addView(card(tv("Jo permission dena hai wahi select karo", 16f), *boxes.toTypedArray(),
                btn("Allow selected") { val sel = all.filterIndexed { i, _ -> boxes[i].isChecked }.map { it.second }.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }; if (sel.isEmpty()) Toast.makeText(this@MainActivity, "Koi nayi permission select nahi ki", Toast.LENGTH_SHORT).show() else requestPermissions(sel.toTypedArray(), 2) }))
            addView(card(tv("Background mein apps kholne ke liye"), btn("Display over apps") {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }))
        }
    }

    private fun openGame(f: () -> View) {
        val v = try { f() } catch (e: Throwable) { tv("Game error: $e") }
        holder.removeAllViews()
        holder.addView(ScrollView(this).apply { addView(col().apply { setPadding(dp(14), dp(8), dp(14), dp(8)); addView(card(v)); addView(btn("Back") { show(::gamesPage) }) }) })
    }
    private fun gamesPage(): LinearLayout = col().apply {
        addView(card(tv("Offline games (bina internet)", 18f),
            btn("Tic-Tac-Toe vs Luna AI") { openGame { Games.ttt(this@MainActivity, fg) } },
            btn("2048") { openGame { Games.g2048(this@MainActivity, fg) } },
            btn("Snake") { openGame { Games.snake(this@MainActivity, fg) } },
            btn("Memory match") { openGame { Games.memory(this@MainActivity, fg) } }))
    }

    private fun aiPage(): LinearLayout {
        val names = provs.map { it + if (it in AiClient.KEYLESS) " ✓ free, key nahi chahiye" else if (!p.getString("key_$it", "").isNullOrEmpty()) " ✓" else "" }
        val sp = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, names); setSelection(provs.indexOf(p.getString("prov", "OVHcloud")).coerceAtLeast(0)) }
        val key = EditText(this).apply { hint = "API key / GitHub token"; setText(p.getString("key_" + provs[sp.selectedItemPosition], "")); setTextColor(fg); setHintTextColor(Color.GRAY) }
        val st = tv("", 14f)
        fun cur() = provs[sp.selectedItemPosition]
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(a: AdapterView<*>?, v: View?, i: Int, l: Long) { key.setText(p.getString("key_" + provs[i], "")) }
            override fun onNothingSelected(a: AdapterView<*>?) {}
        }
        val langs = listOf("Auto (phone ki bhasha)" to "", "हिन्दी Hindi" to "hi-IN", "اردو Urdu" to "ur-PK", "English India (Hinglish)" to "en-IN", "English US" to "en-US",
            "العربية Arabic" to "ar-SA", "বাংলা Bengali" to "bn-IN", "ਪੰਜਾਬੀ Punjabi" to "pa-IN", "தமிழ் Tamil" to "ta-IN", "తెలుగు Telugu" to "te-IN", "Español" to "es-ES", "Français" to "fr-FR")
        val lsp = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, langs.map { it.first })
            setSelection(langs.indexOfFirst { it.second == p.getString("lang", "") }.coerceAtLeast(0))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(a: AdapterView<*>?, v: View?, i: Int, l: Long) { p.edit().putString("lang", langs[i].second).apply() }
                override fun onNothingSelected(a: AdapterView<*>?) {}
            }
        }
        return col().apply {
            addView(card(tv("AI chuno (fail ho to agla auto lagega)", 16f), sp, key,
                btn("🔑 Get key / token") { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(AiClient.provs[cur()] ?: ""))) },
                btn("✅ Test") { st.text = "Test ho raha hai..."; val pr = cur(); val k = key.text.toString().trim(); thread { val r = AiClient.test(pr, k); runOnUiThread { st.text = r } } },
                btn("💾 Save") { p.edit().putString("prov", cur()).putString("key_" + cur(), key.text.toString().trim()).apply(); st.text = "Save ho gaya" }, st))
            addView(card(tv("Bolne ki bhasha (Luna ko stop/start karo)"), lsp))
        }
    }
}
