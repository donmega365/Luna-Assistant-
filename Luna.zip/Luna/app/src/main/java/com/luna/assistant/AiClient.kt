package com.luna.assistant
import android.content.SharedPreferences
import org.json.*
import java.net.*

object AiClient {
    val provs = linkedMapOf(
        "GitHub" to "https://github.com/settings/tokens",
        "Groq" to "https://console.groq.com/keys",
        "Cerebras" to "https://cloud.cerebras.ai",
        "OpenRouter" to "https://openrouter.ai/keys",
        "Mistral" to "https://console.mistral.ai/api-keys",
        "NVIDIA" to "https://build.nvidia.com",
        "SambaNova" to "https://cloud.sambanova.ai",
        "HuggingFace" to "https://huggingface.co/settings/tokens",
        "Gemini" to "https://aistudio.google.com/apikey",
        "Claude" to "https://console.anthropic.com/settings/keys",
        "ChatGPT" to "https://platform.openai.com/api-keys",
        "OVHcloud" to "https://endpoints.ai.cloud.ovh.net",
        "Pollinations" to "https://pollinations.ai")
    // No key / no signup needed (rate-limited free tiers); used as the last resort
    val KEYLESS = setOf("OVHcloud", "Pollinations")
    private fun auth(k: String): Map<String, String> = if (k.isEmpty()) emptyMap() else mapOf("Authorization" to "Bearer $k")
    private const val SYS = "You are Luna, a warm, smart, natural-sounding female voice assistant on the user's phone. Talk like a friendly real human, in 1-3 short sentences, no markdown, no emojis. Reply in the user's own language and style: Hinglish -> Hinglish (Roman letters), Roman Urdu -> Roman Urdu, Hindi -> Hindi (Devanagari), Urdu script -> Urdu script, English -> English, any other language -> that language. Then add a new line: SPEAK(<BCP-47 tag such as hi-IN, ur-PK, en-IN, es-ES>): followed by the same reply written for a text-to-speech voice, i.e. Hindi and Hinglish in Devanagari, Urdu and Roman Urdu in Urdu script, other languages in their own native script, English unchanged."
    private val SPEAK_RE = Regex("(?is)\\s*SPEAK\\s*(?:\\(\\s*([A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,4})?)\\s*\\))?\\s*:\\s*(.*)$")
    private val hist = ArrayList<Pair<String, String>>()   // (user|assistant) to text, last few turns
    private val models = HashMap<String, String>()

    private fun http(method: String, url: String, h: Map<String, String>, body: String?): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method; c.connectTimeout = 15000; c.readTimeout = 40000
        h.forEach { (k, v) -> c.setRequestProperty(k, v) }
        if (body != null) { c.doOutput = true; c.setRequestProperty("Content-Type", "application/json"); c.outputStream.use { it.write(body.toByteArray()) } }
        val code = c.responseCode
        val txt = (if (code < 400) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        if (code < 400 && method == "POST" && !txt.trimStart().startsWith("{")) throw Exception("Unexpected reply [${c.url.host} code=$code]: ${txt.take(80)}")
        if (code >= 400) {
            val msg = try { val j = JSONObject(txt); j.optJSONObject("error")?.optString("message") ?: j.optString("message", txt) } catch (e: Exception) { txt }
            throw Exception("HTTP $code [${c.url.host}] ${msg.take(120)}")
        }
        return txt
    }
    // Picks the newest suitable model from the provider's own /models list, so old model names never break the app
    private fun pick(name: String, base: String, key: String, prefer: List<String>, fb: String): String {
        models[name]?.let { return it }
        try {
            val d = JSONObject(http("GET", "$base/models", auth(key), null)).getJSONArray("data")
            val ids = (0 until d.length()).map { d.getJSONObject(it).getString("id") }
                .filter { id -> listOf("whisper", "guard", "tts", "embed", "orpheus", "audio", "image").none { id.contains(it) } }
            for (p in prefer) ids.firstOrNull { it.contains(p) }?.let { models[name] = it; return it }
        } catch (e: Exception) {}
        return fb
    }
    private fun claudeModel(key: String): String {
        models["Claude"]?.let { return it }
        try {
            val d = JSONObject(http("GET", "https://api.anthropic.com/v1/models", mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), null)).getJSONArray("data")
            for (i in 0 until d.length()) { val id = d.getJSONObject(i).getString("id"); if (id.contains("sonnet")) { models["Claude"] = id; return id } }
        } catch (e: Exception) {}
        return "claude-sonnet-5-5"
    }
    private fun chat(url: String, key: String, model: String, q: String, useHist: Boolean, extra: Map<String, String> = emptyMap()): String {
        val m = JSONArray().put(JSONObject().put("role", "system").put("content", SYS))
        if (useHist) hist.forEach { m.put(JSONObject().put("role", it.first).put("content", it.second)) }
        m.put(JSONObject().put("role", "user").put("content", q))
        val r = JSONObject(http("POST", url, auth(key) + extra, JSONObject().put("model", model).put("messages", m).put("max_tokens", 500).toString()))
        val msg = r.getJSONArray("choices").getJSONObject(0).getJSONObject("message")
        if (msg.isNull("content") || msg.optString("content").isBlank()) throw Exception("model empty reply")
        return msg.getString("content")
    }
    // Tries the provider's own live model list (best match first); if a model is missing/retired it moves to the next one
    private fun chatAuto(name: String, base: String, key: String, prefer: List<String>, fb: String, q: String, useHist: Boolean, only: String? = null): String {
        val ids = try {
            val d = JSONObject(http("GET", "$base/models", auth(key), null)).getJSONArray("data")
            (0 until d.length()).map { d.getJSONObject(it).getString("id") }
                .filter { id -> (only == null || id.contains(only)) && listOf("whisper", "guard", "tts", "embed", "orpheus", "audio", "image", "safeguard").none { id.contains(it) } }
        } catch (e: Exception) { emptyList() }
        val order = (listOfNotNull(models[name]) + prefer.mapNotNull { pf -> ids.firstOrNull { it.contains(pf) } } + ids + listOf(fb)).distinct().take(4)
        var last: Exception? = null
        for (m in order) {
            try { val r = chat("$base/chat/completions", key, m, q, useHist); models[name] = m; return r }
            catch (e: Exception) { last = e; val msg = e.message ?: ""; if (!(msg.contains("404") || msg.contains("400") || msg.contains("model", true))) throw e }
        }
        throw last ?: Exception("model nahi mila")
    }
    private fun raw(provider: String, key: String, q: String, useHist: Boolean): String = when (provider) {
        "Gemini" -> {
            val c = JSONArray()
            if (useHist) hist.forEach { c.put(JSONObject().put("role", if (it.first == "user") "user" else "model").put("parts", JSONArray().put(JSONObject().put("text", it.second)))) }
            c.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", q))))
            val b = JSONObject().put("contents", c).put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYS))))
            JSONObject(http("POST", "https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent?key=$key", mapOf(), b.toString()))
                .getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        }
        "Claude" -> {
            val m = JSONArray()
            if (useHist) hist.forEach { m.put(JSONObject().put("role", it.first).put("content", it.second)) }
            m.put(JSONObject().put("role", "user").put("content", q))
            val b = JSONObject().put("model", claudeModel(key)).put("max_tokens", 400).put("system", SYS).put("messages", m)
            JSONObject(http("POST", "https://api.anthropic.com/v1/messages", mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), b.toString()))
                .getJSONArray("content").getJSONObject(0).getString("text")
        }
        "GitHub" -> chat("https://models.github.ai/inference/chat/completions", key, "openai/gpt-4o-mini", q, useHist, mapOf("Accept" to "application/vnd.github+json", "X-GitHub-Api-Version" to "2022-11-28"))
        "Groq" -> chatAuto("Groq", "https://api.groq.com/openai/v1", key, listOf("gpt-oss-20b", "llama-3.1-8b-instant", "llama-3.3-70b", "gpt-oss-120b", "llama-4", "qwen"), "openai/gpt-oss-20b", q, useHist)
        "Cerebras" -> chatAuto("Cerebras", "https://api.cerebras.ai/v1", key, listOf("gpt-oss", "llama", "qwen"), "llama3.1-8b", q, useHist)
        "OpenRouter" -> chatAuto("OpenRouter", "https://openrouter.ai/api/v1", key, listOf("llama-3.3-70b-instruct:free", "gpt-oss-120b:free", "gpt-oss-20b:free", ":free"), "openai/gpt-oss-20b:free", q, useHist, ":free")
        "Mistral" -> chat("https://api.mistral.ai/v1/chat/completions", key, "mistral-small-latest", q, useHist)
        "NVIDIA" -> chatAuto("NVIDIA", "https://integrate.api.nvidia.com/v1", key, listOf("llama-3.3-70b", "llama-3.1-70b", "nemotron", "llama-3.1-8b"), "meta/llama-3.1-8b-instruct", q, useHist)
        "SambaNova" -> chatAuto("SambaNova", "https://api.sambanova.ai/v1", key, listOf("Llama-3.3-70B", "gpt-oss", "Llama-4", "DeepSeek"), "Meta-Llama-3.3-70B-Instruct", q, useHist)
        "HuggingFace" -> chatAuto("HuggingFace", "https://router.huggingface.co/v1", key, listOf("gpt-oss-20b", "Llama-3.3-70B", "Qwen"), "openai/gpt-oss-20b", q, useHist)
        "OVHcloud" -> chatAuto("OVHcloud", "https://oai.endpoints.kepler.ai.cloud.ovh.net/v1", key, listOf("gpt-oss-20b", "Qwen3.5-9B", "Llama-3_3-70B", "Mistral-Small", "gpt-oss-120b"), "gpt-oss-20b", q, useHist)
        "Pollinations" -> try { chat("https://text.pollinations.ai/openai", "", "openai", q, useHist) } catch (e: Exception) { chat("https://text.pollinations.ai/openai", "", "mistral", q, useHist) }
        else -> chatAuto("ChatGPT", "https://api.openai.com/v1", key, listOf("gpt-4o-mini", "gpt-4.1-mini", "mini"), "gpt-4o-mini", q, useHist)
    }
    @Synchronized fun ask(provider: String, key: String, q: String): String {
        val full = raw(provider, key, q, true).trim()
        val m = SPEAK_RE.find(full)
        val shown = (if (m != null) full.substring(0, m.range.first) else full).trim().ifEmpty { full }
        hist.add("user" to q); hist.add("assistant" to shown); while (hist.size > 12) hist.removeAt(0)
        // shown \u0001 language-tag \u0002 text-to-speech text
        return if (m != null && m.groupValues[2].isNotBlank()) shown + "\u0001" + m.groupValues[1] + "\u0002" + m.groupValues[2].trim() else shown
    }
    fun test(provider: String, key: String): String {
        if (key.isEmpty() && provider !in KEYLESS) return "✗ Pehle key daalo"
        return try { raw(provider, key, "Reply with the single word OK", false); "✓ $provider chal raha hai" } catch (e: Exception) { "✗ ${e.javaClass.simpleName}: ${e.message}" }
    }
    // Selected AI first, then every other AI with a saved key, then keyless free AIs as the last resort
    fun askAny(p: SharedPreferences, q: String): String {
        val first = p.getString("prov", "OVHcloud") ?: "OVHcloud"
        val all = listOf(first) + provs.keys.filter { it != first }
        val order = all.filter { it !in KEYLESS || it == first } + all.filter { it in KEYLESS && it != first }
        var err = ""
        for (n in order) {
            val k = p.getString("key_$n", "") ?: ""
            if (k.isEmpty() && n !in KEYLESS) continue
            try { return ask(n, k, q) } catch (e: Exception) { err = "$n: ${e.javaClass.simpleName} ${e.message}" }
        }
        throw Exception("sab AI fail ho gaye ($err)")
    }
}
