package com.luna.assistant
import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.*
import kotlin.random.Random

// Lightweight animated anime-style background: gradient + glow + falling petals. No bitmaps, ~25fps.
class AuraView(c: Context, private val red: Boolean) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var bg: Shader? = null
    private var t = 0f
    private val n = 18
    private val px = FloatArray(n) { Random.nextFloat() }
    private val py = FloatArray(n) { Random.nextFloat() }
    private val sp = FloatArray(n) { 0.3f + Random.nextFloat() }
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val cs = if (red) intArrayOf(0xFF0B0407.toInt(), 0xFF2B0A14.toInt(), 0xFF7A1224.toInt())
        else intArrayOf(0xFF12082E.toInt(), 0xFF4B2A7A.toInt(), 0xFFE0559F.toInt())
        bg = LinearGradient(0f, 0f, w * 0.4f, h.toFloat(), cs, null, Shader.TileMode.CLAMP)
    }
    override fun onDraw(cv: Canvas) {
        t += 0.03f
        p.shader = bg; cv.drawPaint(p); p.shader = null
        val cx = width * 0.84f; val cy = height * 0.09f
        val r = min(width, height) * 0.06f * (1f + 0.08f * sin(t * 2))
        for (k in 3 downTo 1) { p.color = if (red) Color.argb(35, 255, 60, 80) else Color.argb(35, 255, 190, 255); cv.drawCircle(cx, cy, r * (1f + 0.5f * k), p) }
        p.color = if (red) Color.argb(200, 255, 190, 195) else Color.argb(190, 255, 240, 255); cv.drawCircle(cx, cy, r, p)
        p.color = if (red) Color.argb(150, 255, 70, 90) else Color.argb(150, 255, 200, 230)
        for (i in 0 until n) {
            val y = ((py[i] + t * 0.03f * sp[i]) % 1f) * height
            val x = (px[i] + 0.03f * sin(t + i)) * width
            cv.drawCircle(x, y, 4f + 6f * sp[i], p)
        }
        postInvalidateDelayed(40)
    }
}

// Animated voice bars on both sides of the mic button
class WaveView(c: Context, private val color: Int) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND; strokeWidth = 7f }
    private var t = 0f
    var active = false
    override fun onDraw(cv: Canvas) {
        t += 0.15f
        p.color = color
        val w = width.toFloat(); val h = height.toFloat(); val step = w * 0.36f / 10f
        for (i in 0 until 10) {
            val amp = if (active) 0.2f + 0.8f * abs(sin(t + i * 0.7f)) else 0.1f
            val half = h * 0.4f * amp
            val xl = w * 0.04f + i * step; val xr = w * 0.96f - i * step
            cv.drawLine(xl, h / 2 - half, xl, h / 2 + half, p)
            cv.drawLine(xr, h / 2 - half, xr, h / 2 + half, p)
        }
        postInvalidateDelayed(50)
    }
}
