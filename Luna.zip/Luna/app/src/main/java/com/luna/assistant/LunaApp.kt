package com.luna.assistant
import android.app.Application

// Saves the last crash so the Home page can show it (helps find the bug)
class LunaApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { getSharedPreferences("luna", 0).edit().putString("crash", android.util.Log.getStackTraceString(e).take(1500)).commit() } catch (_: Throwable) {}
            old?.uncaughtException(t, e)
        }
    }
}
